# Almacenamiento de información

