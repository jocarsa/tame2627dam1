# Eliminación de elementos

