# Software tipos, requisitos, licencias

