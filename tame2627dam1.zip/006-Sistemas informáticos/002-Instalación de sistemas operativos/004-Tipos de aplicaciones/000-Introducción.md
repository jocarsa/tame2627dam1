# Tipos de aplicaciones

