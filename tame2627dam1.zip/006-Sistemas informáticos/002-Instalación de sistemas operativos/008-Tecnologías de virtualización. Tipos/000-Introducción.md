# Tecnologías de virtualización. Tipos

