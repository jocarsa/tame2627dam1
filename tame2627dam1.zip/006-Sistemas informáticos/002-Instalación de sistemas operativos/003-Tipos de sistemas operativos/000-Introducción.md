# Tipos de sistemas operativos

