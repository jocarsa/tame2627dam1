# Estructura y componentes procesador

