# Explotación de sistemas microinformáticos

