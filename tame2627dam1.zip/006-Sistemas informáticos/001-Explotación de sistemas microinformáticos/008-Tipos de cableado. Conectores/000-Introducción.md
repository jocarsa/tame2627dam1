# Tipos de cableado. Conectores

