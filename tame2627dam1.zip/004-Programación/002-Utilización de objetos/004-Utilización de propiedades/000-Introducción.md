# Utilización de propiedades

