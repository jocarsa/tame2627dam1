# Características de los objetos

