# Estructuras estáticas y dinámicas

