# Mecanismos de consulta

