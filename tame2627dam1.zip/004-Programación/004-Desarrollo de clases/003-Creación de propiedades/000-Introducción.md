# Creación de propiedades

