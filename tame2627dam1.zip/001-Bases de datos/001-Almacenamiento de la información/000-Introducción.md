# Almacenamiento de la información

