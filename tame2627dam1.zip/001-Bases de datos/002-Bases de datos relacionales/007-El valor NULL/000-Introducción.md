# El valor NULL

