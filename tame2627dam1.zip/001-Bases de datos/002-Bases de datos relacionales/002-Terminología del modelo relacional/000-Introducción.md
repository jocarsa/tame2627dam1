# Terminología del modelo relacional

