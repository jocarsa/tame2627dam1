# Políticas de bloqueo. Concurrencia

