# Agrupamiento de registros

