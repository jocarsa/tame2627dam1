# Consultas de resumen

