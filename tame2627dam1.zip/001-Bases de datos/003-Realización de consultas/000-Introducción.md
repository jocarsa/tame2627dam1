# Realización de consultas

