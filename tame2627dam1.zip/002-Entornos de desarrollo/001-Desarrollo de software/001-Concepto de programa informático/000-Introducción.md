# Concepto de programa informático

