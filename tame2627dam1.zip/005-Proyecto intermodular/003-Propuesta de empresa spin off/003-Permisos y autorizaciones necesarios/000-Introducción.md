# Permisos y autorizaciones necesarios

