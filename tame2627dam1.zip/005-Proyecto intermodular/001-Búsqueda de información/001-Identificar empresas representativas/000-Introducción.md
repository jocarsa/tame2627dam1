# Identificar empresas representativas

