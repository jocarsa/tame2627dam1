# Caracteristicas de los departamentos

