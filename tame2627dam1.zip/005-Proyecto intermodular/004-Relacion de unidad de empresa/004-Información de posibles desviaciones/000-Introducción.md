# Información de posibles desviaciones

