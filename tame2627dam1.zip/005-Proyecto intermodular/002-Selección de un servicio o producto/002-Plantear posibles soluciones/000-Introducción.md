# Plantear posibles soluciones

